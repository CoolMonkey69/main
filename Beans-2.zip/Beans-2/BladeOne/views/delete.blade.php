@extends('app')

@section('content')
<div class="mx-auto" style="width: 200px;">
{{$msg}}

<a href="index.php" class="btn btn-primary ml-3">Home</a>
</div>

@endsection