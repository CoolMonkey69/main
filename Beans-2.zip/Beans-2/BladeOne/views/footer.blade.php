<div class="fixed-bottom jumbotron bg-dark text-white" style="padding: 10px; text-align: center;">
        <h6>bp323620@truro-penwith.ac.uk</h6>
    </div>