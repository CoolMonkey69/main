<?php

use eftec\bladeone\BladeOneLang;

/**
 * @see \myBlade is defined on /BladeOne/examples/testlang.php
 */
myBlade::$dictionary=array(
    'Hat'=>'Sombrero'
    ,'Cat'=>'chat'
    ,'Cats'=>'Chats'
    ,'%s is a nice cat'=>'%s est un gentil chat'

);