<h1>Directive test $mary={!! $mary !!}</h1>

@@lamb($mary)
<hr>
@lamb($mary)
<br><br>
@@lamb()
<hr>
@lamb()
<br><br>

@@calculator(10,20)
<hr>
@calculator(10,20)
<br><br>

@@datetime($now)
<hr>
@datetime($now)
<br><br>
@@datetimert($now)
<hr>
@datetimert($now)

@randomValFromArr(["a", "b", "c"])