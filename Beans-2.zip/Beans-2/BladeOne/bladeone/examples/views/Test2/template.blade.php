<h1> It is the main template</h1>
v1:{{$v1}}<br>
<hr>
@include('Test2.include',['v1'=>2])
<hr>
v1:{{$v1}}<br>
End of the main template