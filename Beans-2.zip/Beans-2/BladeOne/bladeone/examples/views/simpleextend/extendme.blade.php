@section('section1')
    <h2>It is the section1</h2>
@show
@section('section2')
    <h2>It is the section2</h2>
@show