@section('js_bottom')
    here goes the ckeditor {!! $textarea_id !!}...<br>
@show