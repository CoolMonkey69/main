@input(type=text name='txt1' value='hello" world' placeholder="it is a placeholder" onclick="alert('hello');"")
