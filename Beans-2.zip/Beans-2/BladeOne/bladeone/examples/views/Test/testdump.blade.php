@dump($records)

<hr>

@text("hello=world")


@text(aaa=222 bbb="20000")
@text(['aaa'=>222,'bbb'=>"20000"])

@text(aaa=222 bbb=["a1"=>$a5])


