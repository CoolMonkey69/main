<div>
    @@include('shared.display',["s1"=>"scope 1","s2"=>"scope 2"])<br>
    @include('shared.display',["s1"=>"scope 1","s2"=>"scope 2"])<br>
    @@include('shared.display',[])<br>
    @include('shared.display',[])


    
    <hr>
</div>