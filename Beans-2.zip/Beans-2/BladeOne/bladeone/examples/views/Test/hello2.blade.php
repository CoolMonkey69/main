@extends('Shared.newlayout')

@section('content')
    <div style="background-color: rosybrown">
    {{$other}} {{$v1}}
    <br>IT IS THE SECTION CONTENT<br>
    <br>
    <br>
    <br>END OF THE SECTION CONTENT
    </div>
@stop


@section('footer')
    <div style="background-color: darkred">
   IT IS THE SECTION FOOTER<br>
   <br>
   <br>
   <br>END OF THE SECTION FOOTER
    </div>
@stop

