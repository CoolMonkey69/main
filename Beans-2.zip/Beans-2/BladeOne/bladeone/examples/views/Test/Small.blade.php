name1:
{!! $name !!}
<br>
name2:
aaaa@@abc

 @def

<br>
name3:
{{$name}}