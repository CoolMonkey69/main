<hr>start<hr>
@includefast('Test.master')
<hr>end<hr>