@input()
@input(['type' => 'email','value'=>'billgates@microsoft.com'])