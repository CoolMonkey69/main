*example2.blade.php*
@extends('composer.layout')

@section('content')
    *content*
    {{$content}}
@endsection